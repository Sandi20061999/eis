<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Default Tab</h4>
                <?= $tab ?>
            </div>
        </div>
    </div>
</div>