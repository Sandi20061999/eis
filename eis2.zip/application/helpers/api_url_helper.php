<?php
function API_URL()
{
    return 'http://api.darmajaya.ac.id:8795/service_dev/api/view_eis/lists/format/json';
}