<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				<div class="row d-flex justify-content-between">
					<h4 class="card-title">Data Table</h4>
				</div>
				<?php echo form_open('user_view/add', array("class" => "form-horizontal")); ?>
				<div class="form-group">
					<div class="col-md-6">
						<label for="type" class="control-label"><span class="text-danger">*</span>Type</label>
						<div class="form-group">
							<select name="type" class="form-control" id="select_type">
								<option value="">select</option>
								<?php
								$type_values = array(
									'table' => 'Table',
									'accordion-table' => 'Accordion and Table',
									'morris-line-chart' => 'Morris Line Chart',
									'morris-bar-chart' => 'Morris Bar Chart',
									// 'grid' => 'Grid',
									'tab' => 'Tab',
									'header' => 'Header',
									'card' => 'Card',
								);

								foreach ($type_values as $value => $display_text) {
									$selected = ($value == $this->input->post('type')) ? ' selected="selected"' : "";

									echo '<option id="' . $value . '" value="' . $value . '" ' . $selected . '>' . $display_text . '</option>';
								}
								?>
							</select>
							<span class="text-danger"><?php echo form_error('type'); ?></span>
						</div>
					</div>
				</div>
				<div id="pertype">

					<!-- table -->

					<!-- Accordion Table -->

					<!-- header -->

					<!-- chart -->

					<!-- card -->

					<!-- tab -->

				</div>
				<div class="form-group">
					<div class="col-md-6">
						<label for="type" class="control-label"><span class="text-danger">*</span>API</label>
						<div class="form-group">
							<select name="type" class="form-control" id="api"></select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6"> <label for="cardWidth" class="control-label">Card Width</label>
						<div class="form-group"> <input type="text" name="cardWidth" value="<?php echo $this->input->post('cardWidth'); ?>" class="form-control" id="cardWidth" /> </div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6"> <label for="cardValue" class="control-label">Card Value</label>
						<div class="form-group"> <input type="text" name="cardValue" value="<?php echo $this->input->post('cardValue'); ?>" class="form-control" id="cardValue" /> </div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6"> <label for="cardDetail" class="control-label">Card Detail</label>
						<div class="form-group"> <input type="text" name="cardDetail" value="<?php echo $this->input->post('cardDetail'); ?>" class="form-control" id="cardDetail" /> </div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6"> <label for="cardIcon" class="control-label">Card Icon</label>
						<div class="form-group"> <input type="text" name="cardIcon" value="<?php echo $this->input->post('cardIcon'); ?>" class="form-control" id="cardIcon" /> </div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-6"> <label for="cardColor" class="control-label">Card Color</label>
						<div class="form-group"> <input type="text" name="cardColor" value="<?php echo $this->input->post('cardColor'); ?>" class="form-control" id="cardColor" /> </div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-4 col-sm-8">
						<button type="submit" class="btn btn-success">Save</button>
					</div>
				</div>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
</div>