    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo $title; ?></h4>
                    <p><?php echo $label; ?></p>
                    <div id="<?php echo $id; ?>"></div>
                </div>
            </div>
        </div>
    </div>