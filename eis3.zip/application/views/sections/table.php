<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="my-auto"><?php echo $title; ?></h5>
        </div>
        <div class="card-body">
            <?php echo $table; ?>
        </div>
    </div>
</div>