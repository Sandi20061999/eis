<!-- <div class="row"> -->
    <div class="col-md-<?=$width?>" id="cardcukkks<?= $u;?>">
    </div>
<!-- </div> -->
<?= $modal; ?>