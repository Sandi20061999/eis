<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <canvas id="canvas" width="1000" height="500" class="chartjs-render-monitor"></canvas>
        </div>
    </div>
</div>