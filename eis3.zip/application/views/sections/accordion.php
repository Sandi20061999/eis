<?php
echo $accordion;
