<?php

use Jajo\JSONDB;

class Core_system extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('User_access_menu_model');
        $this->load->model('User_access_sub_menu_model');
        $this->load->model('Core_system_model');
    }
    // function getColor($num)
    // {
    //     $hash = md5('color' . $num); // modify 'color' to get a different palette
    //     return array(
    //         hexdec(substr($hash, 0, 2)), // r
    //         hexdec(substr($hash, 2, 2)), // g
    //         hexdec(substr($hash, 4, 2))
    //     ); //b
    // }
    function index($uid)
    {
        // var_dump($this->getColor(5));
        // die;
        $data['menu'] = $this->db->join('menu', 'menu.id=role_access_menu.menu_id')->get_where('role_access_menu', array('role_id' => $this->session->userdata('role_id')))->result_array();
        $data['subMenu'] = $this->db->join('sub_menu', 'sub_menu.id=role_access_sub_menu.sub_menu_id')->get_where('role_access_sub_menu', array('role_id' => $this->session->userdata('role_id')))->result_array();
        $this->load->view('layouts/header');
        $this->load->view('layouts/sidebar', $data);
        $getView = $this->Core_system_model->getView('core_system/index/' . $uid);
        $cfoo = array();
        $au = 0;
        foreach ($getView as $gV) {

            if ($gV['type'] == 'card') {
                if ($gV['jsonFile'] == null) {
                    $dataValue = $this->_api($gV['select'], $gV['view_name'], $gV['where'], $gV['limit'], $gV['order_by']);
                    $json_db = new JSONDB($dataValue);
                    $users = $json_db->select('no_pendaftar, no_test, nama, id_jurusan, ta')
                        ->from()
                        ->where(json_decode($gV['cardFilter'], true), 'AND')
                        ->get();
                } else {
                    $json_db = new JSONDB($gV['jsonFile']);
                    $users = $json_db->select('no_pendaftar, no_test, nama, id_jurusan, ta')
                        ->from()
                        ->where(json_decode($gV['cardFilter'], true), 'AND')
                        ->get();
                }
                $cd = [
                    'title' => $gV['cardTitle'],
                    'width' => $gV['cardWidth'], // lebar 1 - 12 default 12
                    'nilai' => count($users), // value 
                    'detail' => $gV['cardDetail'], // detail *optional
                    'icon' => $gV['cardIcon'], // icon fontawesomw fa fa-user
                    'color' => $gV['cardColor'], // primary,danger,success,warning,red,blue,green.yellow,purple,white
                ];
                $card['card'] = card($cd);
                $this->load->view('sections/card', $card);
            }

            $au++;
        }
        $this->load->view('sections/chartjs');
        $val['javascript'] = $cfoo;
        $this->load->view('layouts/footer', $val);
    }

    function _api($select, $view_name, $where, $limit, $order_by)
    {
        $datapost = [
            "select" => $select,
            "view_name" => $view_name,
            "where" => $where,
            "limit" => $limit,
            "order_by" => $order_by
        ];
        $getmhs = $this->curl->simple_post(API_URL(), $datapost);
        return json_decode($getmhs, true);
    }
}
