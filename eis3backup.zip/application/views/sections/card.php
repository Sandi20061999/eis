
    <?php 
        echo $card;
     ?>
